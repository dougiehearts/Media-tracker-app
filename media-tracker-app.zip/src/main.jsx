
import React from 'react';
import ReactDOM from 'react-dom/client';
import MediaTracker from './MediaTracker.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <MediaTracker />
  </React.StrictMode>
);
