
import { useState } from 'react';

const mockData = [
  { id: 1, title: "The Boys", type: "series", watchedEpisodes: 6, totalEpisodes: 8, newEpisode: true },
  { id: 2, title: "House of the Dragon", type: "series", watchedEpisodes: 2, totalEpisodes: 2, newEpisode: false },
  { id: 3, title: "Dune: Part Two", type: "movie", watched: true },
  { id: 4, title: "Mission Impossible 8", type: "movie", watched: false },
];

export default function MediaTracker() {
  const [mediaList, setMediaList] = useState(mockData);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  const toggleWatched = (id) => {
    setMediaList(prev => prev.map(m =>
      m.id === id ? { ...m, watched: !m.watched } : m
    ));
  };

  const toggleEpisodeWatched = (id) => {
    setMediaList(prev => prev.map(m =>
      m.id === id && m.type === 'series' ? { ...m, watchedEpisodes: m.watchedEpisodes + 1 } : m
    ));
  };

  const filteredList = mediaList.filter(m => {
    if (filter === 'all') return true;
    if (filter === 'watched') return m.watched || m.watchedEpisodes === m.totalEpisodes;
    if (filter === 'unwatched') return !m.watched && (m.watchedEpisodes || 0) < (m.totalEpisodes || 1);
    return true;
  }).filter(m => m.title.toLowerCase().includes(search.toLowerCase()));

  return (
    <div style={{ padding: '2rem' }}>
      <h1>🎬 My Media Tracker</h1>
      <input
        type="text"
        placeholder="Search movies or series..."
        value={search}
        onChange={e => setSearch(e.target.value)}
        style={{ padding: '0.5rem', margin: '1rem 0', width: '100%' }}
      />
      <select value={filter} onChange={e => setFilter(e.target.value)} style={{ marginBottom: '1rem' }}>
        <option value="all">All</option>
        <option value="watched">Watched</option>
        <option value="unwatched">Unwatched</option>
      </select>
      {filteredList.map(item => (
        <div key={item.id} style={{ border: '1px solid #ccc', padding: '1rem', marginBottom: '1rem' }}>
          <h2>{item.title}</h2>
          {item.type === 'movie' ? (
            <>
              <p>Status: {item.watched ? 'Watched' : 'Unwatched'}</p>
              <button onClick={() => toggleWatched(item.id)}>
                Mark as {item.watched ? 'Unwatched' : 'Watched'}
              </button>
            </>
          ) : (
            <>
              <p>Episodes watched: {item.watchedEpisodes}/{item.totalEpisodes}</p>
              <button onClick={() => toggleEpisodeWatched(item.id)}>
                Mark Next Episode Watched
              </button>
            </>
          )}
        </div>
      ))}
    </div>
  );
}
